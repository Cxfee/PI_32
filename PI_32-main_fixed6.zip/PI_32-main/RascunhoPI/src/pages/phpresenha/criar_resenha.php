<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<link rel="stylesheet" href="../../../public/css/fonts.css" />
<link rel="stylesheet" href="../../../public/css/global.css" />
<link rel="stylesheet" href="resenha.css" />
<title>Criar Resenha</title>
</head>
<body>
<main class="container" style="padding:20px;">
    <h1>Criar Resenha</h1>
    <form action="resenha-processo.php" method="post">
        <label for="nomeproduto">Nome do produto</label><br/>
        <input type="text" id="nomeproduto" name="nomeproduto" required /><br/>
        <label for="tipoproduto">Tipo do produto</label><br/>
        <input type="text" id="tipoproduto" name="tipoproduto" required /><br/>
        <label for="precoproduto">Preço</label><br/>
        <input type="number" step="0.01" id="precoproduto" name="precoproduto" required /><br/>
        <label for="resenha">Resenha</label><br/>
        <textarea id="resenha" name="resenha" rows="6" required></textarea><br/>
        <button type="submit" class="botao">Enviar Resenha</button>
    </form>
    <p style="margin-top:12px;">
        <a class="botao" href="resenha.php">Voltar para Resenhas</a>
        &nbsp;
        <a class="botao" href="../phplogin/logout.php">Logout</a>
    </p>
</main>
</body>
</html>
