<?php
session_start();
include('conexao.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['nomeusuario']);
    $senha = trim($_POST['senha']);

    if (empty($usuario) || empty($senha)) {
        echo "<script>alert('Preencha todos os campos.'); history.back();</script>";
        exit;
    }

    $stmt = $conexao->prepare("SELECT * FROM usuarios WHERE nomeusuario = ?");
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($senha, $user['senha'])) {
            $_SESSION['usuario'] = $user['nomeusuario'];
            header("Location: /PI_32-main/RascunhoPI/src/pages/phpresenha/resenha.php");
            exit;
        } else {
            echo "<script>alert('Senha incorreta.'); history.back();</script>";
            exit;
        }
    } else {
        echo "<script>alert('Usuário não encontrado.'); history.back();</script>";
        exit;
    }
}
?>
