<?php
// conexao.php — conexão central com o banco pi_32

$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "pi_32";

$conexao = new mysqli($servidor, $usuario, $senha, $banco);

// Verifica conexão
if ($conexao->connect_error) {
    die("Falha na conexão: " . $conexao->connect_error);
}
?>
